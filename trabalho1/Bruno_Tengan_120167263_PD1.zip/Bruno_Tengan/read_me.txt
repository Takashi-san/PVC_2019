Aluno: Bruno Takashi Tengan
Matrícula: 12/0167263

Programas desenvolvidos no ambiente:
OS: Linux Ubuntu 16.04
Python: Python 2.7.12
OpenCV: OpenCV 3.3.1-dev

Argumentos de execução:
Imagem--------------------------
trab1_img.py caminho_img
	# executa com a imagem indicado no caminho.

Video---------------------------
trab1_video.py caminho_video
	# executa com o vídeo indicado no caminho.

Stream--------------------------
trab1_stream.py
	# executa com o primeiro dispositivo de câmera identificado pelo OpenCV.

